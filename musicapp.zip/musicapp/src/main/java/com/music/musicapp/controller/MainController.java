package com.music.musicapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.music.musicapp.model.User;

@Controller
@RequestMapping("/")
public class MainController {
	
	
	@RequestMapping("/home")
	public String homePage()
	{
		ModelAndView modelAndView = new ModelAndView();
		User user = new User();
		user.setId(1);
		user.setName("user1");
		modelAndView.addObject(user);
		
		return "home";
	}

}
