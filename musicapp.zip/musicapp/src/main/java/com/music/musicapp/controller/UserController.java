package com.music.musicapp.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController("/user")
public class UserController {
	
	


}
