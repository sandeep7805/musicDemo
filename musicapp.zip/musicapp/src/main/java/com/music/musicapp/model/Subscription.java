package com.music.musicapp.model;

public class Subscription {

}
